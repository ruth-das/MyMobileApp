package com.mobile.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.mobile.exception.MobileException;

public class DBConnection {

	public static Connection getConnection() throws MobileException {
		Connection con = null;
		Properties props = new Properties();

		try {
			FileReader fRead = new FileReader("resource/jdbc.properties");
			props.load(fRead);

			String url = props.getProperty("jdbcurl");
			String user = props.getProperty("user");
			String pass = props.getProperty("pass");

			con = DriverManager.getConnection(url, user, pass);
		} catch (FileNotFoundException e) {
			throw new MobileException("jdbc.properties File not Found");

		} catch (IOException e) {
			throw new MobileException("Unable to read jdbc.properties file");

		} catch (SQLException e) {
			throw new MobileException("Connection failed");

		}
		return (con);
	}
}
