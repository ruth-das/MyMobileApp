package com.mobile.service;

import com.mobile.bean.MobileBean;
import com.mobile.dao.MobileDao;
import com.mobile.dao.MobileDaoImpl;
import com.mobile.exception.MobileException;

public class MobileServiceImpl implements MobileService{

	private MobileDao employeedao = new MobileDaoImpl();

	@Override
	public int addCustomer(MobileBean bean) throws MobileException 
	{
		int id= employeedao.addCustomer(bean);
		return id;
	}
}
