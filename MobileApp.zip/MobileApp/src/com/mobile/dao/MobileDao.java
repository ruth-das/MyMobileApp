package com.mobile.dao;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;

public interface MobileDao {

	int addCustomer(MobileBean bean)throws MobileException;

}
