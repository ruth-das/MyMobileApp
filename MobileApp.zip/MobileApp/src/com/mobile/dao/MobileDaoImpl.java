package com.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;
import com.mobile.util.DBConnection;

public class MobileDaoImpl implements MobileDao{

	public int generatePurchaseId() {
		int id = 0;
		Connection con = null;
		String str = "select purchaseid_seq.nextval from dual";
		try {
			// logger.info("connecting to database for generating id..");
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id = rs.getInt(1);

			// logger.info("id generated..\n");
		} catch (Exception e) {
			// logger.info("id can not be generated..\n");
			System.out.println("id can not generated.try again!");
		}
		return id;
	}
	
	public int addCustomer(MobileBean bean) throws MobileException
	{
		int id=0;
		Connection con= null;
	
		String cmd="insert into purchasedetails values(?,?,?,?,sysdate,?)";
		
		try 
		{
			//logger.debug("connecting to database for adding purchase details of customer..");
			con=DBConnection.getConnection();
			id=generatePurchaseId();
	
			PreparedStatement ps = con.prepareStatement(cmd);
			
			ps.setInt(1,id);
			ps.setString(2,bean.getCustName());
			ps.setString(3, bean.getMailId());
			ps.setLong(4, bean.getPhoneNo());
			ps.setInt(5, bean.getMobileId());
			
			int n=ps.executeUpdate();
			//System.out.println(n);
			if(n==0)
			{
				//logger.error("exception while adding database..\n");
				throw new MobileException("unable to insert");
			}
			else
			{
				//logger.debug("purchase details added, updating mobiles table..");
				String cmd1="update mobiles set quantity = quantity-1 where mobileid = ?";
				PreparedStatement ps1=con.prepareStatement(cmd1);
				ps1.setInt(1,bean.getMobileId());
				int i= ps1.executeUpdate();
				//System.out.println(i);
				//logger.info("mobiles table updated..\n");
			}
		}
		catch (Exception e) 
		{
			//logger.error("exception while adding details..\n");
			throw new MobileException("mobile id not found");
		} 
		return id;
	}
}
