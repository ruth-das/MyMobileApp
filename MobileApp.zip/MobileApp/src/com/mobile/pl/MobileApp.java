package com.mobile.pl;

import java.util.Scanner;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;
import com.mobile.service.MobileService;
import com.mobile.service.MobileServiceImpl;

public class MobileApp {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		MobileBean bean = new MobileBean();
		
		System.out.println("Select Operations:"
				+ "\n1.Insert the customer and purchase details into database."
				+ "\n2.View details of all mobiles available in the shop."
				+ "\n3.Delete a mobile details based on mobile id."
				+ "\n4.Search mobiles based on price range.");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter Customer Name: ");
			String cname=sc.next();
			System.out.println("Enter customer Mail Id: ");
			String cmail=sc.next();
			System.out.println("Enter Customer Phone Number: ");
			long phno=sc.nextLong();
			System.out.println("Enter Mobile Id: ");
			int mid=sc.nextInt();
			
			bean.setCustName(cname);
			bean.setMailId(cmail);
			bean.setPhoneNo(phno);
			bean.setMobileId(mid);
			
			MobileService service = new MobileServiceImpl();
			try {
				int n=service.addCustomer(bean);
				System.out.println("Customer details added. ID = "+n);
				//logger.info("Employee Added Successfully");
			} catch (MobileException e) {
				System.out.println(e);
				//logger.info("Could not add employee", e);
			}
			
			break;
			
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		}
		sc.close();
	}
}
